package com.google.android.gms.internal;

public interface zzmd {

    public static class zza implements zzmd {
        public void zza(Throwable th, String str) {
        }
    }

    void zza(Throwable th, String str);
}
