package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.zzb;

public abstract class zzabz<A extends zzb, L> {
    private final zzabh.zzb<L> zzaCY;

    public zzabh.zzb<L> zzwW() {
        return this.zzaCY;
    }
}
