package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.zze;
import com.google.android.gms.common.internal.zzr;

public interface zzbai extends zze {
    void connect();

    void zzPJ();

    void zza(zzr com_google_android_gms_common_internal_zzr, boolean z);

    void zza(zzbap com_google_android_gms_internal_zzbap);
}
