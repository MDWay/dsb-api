package com.google.android.gms.internal;

import android.support.customtabs.CustomTabsClient;

public interface zzbyc {
    void zza(CustomTabsClient customTabsClient);

    void zzfI();
}
