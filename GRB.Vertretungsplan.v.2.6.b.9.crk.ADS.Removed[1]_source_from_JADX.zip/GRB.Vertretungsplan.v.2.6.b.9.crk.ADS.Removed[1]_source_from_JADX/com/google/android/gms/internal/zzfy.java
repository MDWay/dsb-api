package com.google.android.gms.internal;

import java.util.List;

public interface zzfy {
    List<String> zza(zzmk com_google_android_gms_internal_zzmk);
}
