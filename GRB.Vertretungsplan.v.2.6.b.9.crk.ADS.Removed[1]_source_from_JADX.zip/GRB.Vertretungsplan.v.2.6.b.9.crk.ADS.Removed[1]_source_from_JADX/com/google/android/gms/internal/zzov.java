package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.internal.zzcy.zza;
import com.google.android.gms.internal.zzcy.zzb;

@zzme
public class zzov implements zzb {
    private final Context mContext;
    boolean zzVV = false;
    private final Object zzrJ = new Object();
    private final String zzts;

    public zzov(Context context, String str) {
        this.mContext = context;
        this.zzts = str;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void zzC(boolean r5) {
        /*
        r4 = this;
        r0 = com.google.android.gms.ads.internal.zzw.zzdl();
        r0 = r0.zzjQ();
        if (r0 != 0) goto L_0x000b;
    L_0x000a:
        return;
    L_0x000b:
        r1 = r4.zzrJ;
        monitor-enter(r1);
        r0 = r4.zzVV;	 Catch:{ all -> 0x0014 }
        if (r0 != r5) goto L_0x0017;
    L_0x0012:
        monitor-exit(r1);	 Catch:{ all -> 0x0014 }
        goto L_0x000a;
    L_0x0014:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x0014 }
        throw r0;
    L_0x0017:
        r4.zzVV = r5;	 Catch:{ all -> 0x0014 }
        r0 = r4.zzVV;	 Catch:{ all -> 0x0014 }
        if (r0 == 0) goto L_0x002a;
    L_0x001d:
        r0 = com.google.android.gms.ads.internal.zzw.zzdl();	 Catch:{ all -> 0x0014 }
        r2 = r4.mContext;	 Catch:{ all -> 0x0014 }
        r3 = r4.zzts;	 Catch:{ all -> 0x0014 }
        r0.zzd(r2, r3);	 Catch:{ all -> 0x0014 }
    L_0x0028:
        monitor-exit(r1);	 Catch:{ all -> 0x0014 }
        goto L_0x000a;
    L_0x002a:
        r0 = com.google.android.gms.ads.internal.zzw.zzdl();	 Catch:{ all -> 0x0014 }
        r2 = r4.mContext;	 Catch:{ all -> 0x0014 }
        r3 = r4.zzts;	 Catch:{ all -> 0x0014 }
        r0.zze(r2, r3);	 Catch:{ all -> 0x0014 }
        goto L_0x0028;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzov.zzC(boolean):void");
    }

    public void zza(zza com_google_android_gms_internal_zzcy_zza) {
        zzC(com_google_android_gms_internal_zzcy_zza.zzxl);
    }
}
