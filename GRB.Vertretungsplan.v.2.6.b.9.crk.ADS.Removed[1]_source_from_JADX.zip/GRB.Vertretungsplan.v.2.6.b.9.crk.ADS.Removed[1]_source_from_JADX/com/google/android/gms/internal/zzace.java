package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.internal.zzack.zza;

public class zzace extends zza {
    public void zzdd(int i) throws RemoteException {
    }
}
