package com.google.android.gms.internal;

import org.json.JSONObject;

public interface zzcx {
    void zzc(JSONObject jSONObject, boolean z);

    boolean zzdV();

    void zzdW();
}
