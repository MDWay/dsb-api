package com.google.android.gms.internal;

public class zzi extends zzs {
    public zzi(Throwable th) {
        super(th);
    }
}
