package com.google.android.gms.internal;

import java.util.concurrent.Future;

public interface zzox {
    Future<String> zzaS(String str);
}
