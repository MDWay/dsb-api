package com.google.android.gms.internal;

import java.util.concurrent.Future;

public interface zzqm<A> extends Future<A> {
    void zzc(Runnable runnable);

    void zzd(Runnable runnable);
}
