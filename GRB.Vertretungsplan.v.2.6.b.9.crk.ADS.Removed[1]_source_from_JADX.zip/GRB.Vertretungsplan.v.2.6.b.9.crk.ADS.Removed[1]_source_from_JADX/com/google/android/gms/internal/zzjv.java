package com.google.android.gms.internal;

@zzme
public final class zzjv {
    public final int zzLh;
    public final zzjq zzLi;
    public final zzkb zzLj;
    public final String zzLk;
    public final zzjt zzLl;
    public final zzkd zzLm;
    public final long zzLn;

    public interface zza {
        void zzF(int i);

        void zza(int i, zzkd com_google_android_gms_internal_zzkd);
    }

    public zzjv(int i) {
        this(null, null, null, null, i, null, 0);
    }

    public zzjv(zzjq com_google_android_gms_internal_zzjq, zzkb com_google_android_gms_internal_zzkb, String str, zzjt com_google_android_gms_internal_zzjt, int i, zzkd com_google_android_gms_internal_zzkd, long j) {
        this.zzLi = com_google_android_gms_internal_zzjq;
        this.zzLj = com_google_android_gms_internal_zzkb;
        this.zzLk = str;
        this.zzLl = com_google_android_gms_internal_zzjt;
        this.zzLh = i;
        this.zzLm = com_google_android_gms_internal_zzkd;
        this.zzLn = j;
    }
}
