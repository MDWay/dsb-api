package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.zzey.zza;

public class zzfm extends zza {
    public void initialize() throws RemoteException {
    }

    public void setAppMuted(boolean z) throws RemoteException {
    }

    public void setAppVolume(float f) throws RemoteException {
    }

    public void zzb(IObjectWrapper iObjectWrapper, String str) throws RemoteException {
    }

    public void zzc(String str, IObjectWrapper iObjectWrapper) throws RemoteException {
    }

    public void zzy(String str) throws RemoteException {
    }
}
