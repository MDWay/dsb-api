package com.google.android.gms.internal;

import android.support.annotation.NonNull;
import com.google.firebase.FirebaseException;

public class zzbtk extends FirebaseException {
    public zzbtk(@NonNull String str) {
        super(str);
    }
}
