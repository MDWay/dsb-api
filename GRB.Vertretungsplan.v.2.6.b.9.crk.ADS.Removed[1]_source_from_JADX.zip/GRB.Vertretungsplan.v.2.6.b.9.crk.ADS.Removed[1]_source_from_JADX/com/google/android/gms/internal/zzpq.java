package com.google.android.gms.internal;

@zzme
public interface zzpq<T> {
    void cancel();

    T zziP();
}
