package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.identifier.AdvertisingIdClient.Info;

public interface zzpa {
    zzqm<Info> zzG(Context context);

    zzqm<String> zzg(zzmk com_google_android_gms_internal_zzmk);
}
