package com.google.android.gms.internal;

public interface zzng {
}
