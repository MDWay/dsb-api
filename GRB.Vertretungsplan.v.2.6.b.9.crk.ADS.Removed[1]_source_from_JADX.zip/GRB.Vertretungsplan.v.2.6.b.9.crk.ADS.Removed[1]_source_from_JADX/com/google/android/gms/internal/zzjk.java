package com.google.android.gms.internal;

public interface zzjk extends zzjj {
    void zzgT();
}
