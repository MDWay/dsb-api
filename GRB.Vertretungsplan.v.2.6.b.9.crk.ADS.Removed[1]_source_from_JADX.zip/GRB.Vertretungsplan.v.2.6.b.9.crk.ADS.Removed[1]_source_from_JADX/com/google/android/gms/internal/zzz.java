package com.google.android.gms.internal;

import java.io.IOException;
import java.util.Map;
import org.apache.http.HttpResponse;

public interface zzz {
    HttpResponse zza(zzl<?> com_google_android_gms_internal_zzl_, Map<String, String> map) throws IOException, zza;
}
