package com.google.android.gms.internal;

public interface zzpt<T> {
    void zzd(T t);
}
