package com.google.android.gms.internal;

import android.content.Context;
import android.support.annotation.Nullable;
import com.google.android.gms.ads.internal.zzw;
import com.google.android.gms.common.internal.zzac;
import java.util.Map;

@zzme
public class zzji {
    private final Context mContext;
    private final String zzJK;
    private zzpt<zzjf> zzJL;
    private zzpt<zzjf> zzJM;
    @Nullable
    private zzd zzJN;
    private int zzJO;
    private final Object zzrJ;
    private final zzqh zztt;

    static class zza {
        static int zzJZ = 60000;
        static int zzKa = 10000;
    }

    public static class zzb<T> implements zzpt<T> {
        public void zzd(T t) {
        }
    }

    public static class zzc extends zzqq<zzjj> {
        private final zzd zzKb;
        private boolean zzKc;
        private final Object zzrJ = new Object();

        class C08871 implements com.google.android.gms.internal.zzqp.zzc<zzjj> {
            C08871(zzc com_google_android_gms_internal_zzji_zzc) {
            }

            public void zzb(zzjj com_google_android_gms_internal_zzjj) {
                zzpk.m15v("Ending javascript session.");
                ((zzjk) com_google_android_gms_internal_zzjj).zzgT();
            }

            public /* synthetic */ void zzd(Object obj) {
                zzb((zzjj) obj);
            }
        }

        class C08882 implements com.google.android.gms.internal.zzqp.zzc<zzjj> {
            final /* synthetic */ zzc zzKd;

            C08882(zzc com_google_android_gms_internal_zzji_zzc) {
                this.zzKd = com_google_android_gms_internal_zzji_zzc;
            }

            public void zzb(zzjj com_google_android_gms_internal_zzjj) {
                zzpk.m15v("Releasing engine reference.");
                this.zzKd.zzKb.zzgQ();
            }

            public /* synthetic */ void zzd(Object obj) {
                zzb((zzjj) obj);
            }
        }

        class C08893 implements com.google.android.gms.internal.zzqp.zza {
            final /* synthetic */ zzc zzKd;

            C08893(zzc com_google_android_gms_internal_zzji_zzc) {
                this.zzKd = com_google_android_gms_internal_zzji_zzc;
            }

            public void run() {
                this.zzKd.zzKb.zzgQ();
            }
        }

        public zzc(zzd com_google_android_gms_internal_zzji_zzd) {
            this.zzKb = com_google_android_gms_internal_zzji_zzd;
        }

        public void release() {
            synchronized (this.zzrJ) {
                if (this.zzKc) {
                    return;
                }
                this.zzKc = true;
                zza(new C08871(this), new com.google.android.gms.internal.zzqp.zzb());
                zza(new C08882(this), new C08893(this));
            }
        }
    }

    public static class zzd extends zzqq<zzjf> {
        private zzpt<zzjf> zzJM;
        private boolean zzKe;
        private int zzKf;
        private final Object zzrJ = new Object();

        class C08923 implements com.google.android.gms.internal.zzqp.zzc<zzjf> {
            final /* synthetic */ zzd zzKh;

            C08923(zzd com_google_android_gms_internal_zzji_zzd) {
                this.zzKh = com_google_android_gms_internal_zzji_zzd;
            }

            public void zza(final zzjf com_google_android_gms_internal_zzjf) {
                zzw.zzcM().runOnUiThread(new Runnable(this) {
                    final /* synthetic */ C08923 zzKj;

                    public void run() {
                        this.zzKj.zzKh.zzJM.zzd(com_google_android_gms_internal_zzjf);
                        com_google_android_gms_internal_zzjf.destroy();
                    }
                });
            }

            public /* synthetic */ void zzd(Object obj) {
                zza((zzjf) obj);
            }
        }

        public zzd(zzpt<zzjf> com_google_android_gms_internal_zzpt_com_google_android_gms_internal_zzjf) {
            this.zzJM = com_google_android_gms_internal_zzpt_com_google_android_gms_internal_zzjf;
            this.zzKe = false;
            this.zzKf = 0;
        }

        public zzc zzgP() {
            final zzc com_google_android_gms_internal_zzji_zzc = new zzc(this);
            synchronized (this.zzrJ) {
                zza(new com.google.android.gms.internal.zzqp.zzc<zzjf>(this) {
                    public void zza(zzjf com_google_android_gms_internal_zzjf) {
                        zzpk.m15v("Getting a new session for JS Engine.");
                        com_google_android_gms_internal_zzji_zzc.zzg(com_google_android_gms_internal_zzjf.zzgM());
                    }

                    public /* synthetic */ void zzd(Object obj) {
                        zza((zzjf) obj);
                    }
                }, new com.google.android.gms.internal.zzqp.zza(this) {
                    public void run() {
                        zzpk.m15v("Rejecting reference for JS Engine.");
                        com_google_android_gms_internal_zzji_zzc.reject();
                    }
                });
                zzac.zzaw(this.zzKf >= 0);
                this.zzKf++;
            }
            return com_google_android_gms_internal_zzji_zzc;
        }

        protected void zzgQ() {
            boolean z = true;
            synchronized (this.zzrJ) {
                if (this.zzKf < 1) {
                    z = false;
                }
                zzac.zzaw(z);
                zzpk.m15v("Releasing 1 reference for JS Engine");
                this.zzKf--;
                zzgS();
            }
        }

        public void zzgR() {
            boolean z = true;
            synchronized (this.zzrJ) {
                if (this.zzKf < 0) {
                    z = false;
                }
                zzac.zzaw(z);
                zzpk.m15v("Releasing root reference. JS Engine will be destroyed once other references are released.");
                this.zzKe = true;
                zzgS();
            }
        }

        protected void zzgS() {
            synchronized (this.zzrJ) {
                zzac.zzaw(this.zzKf >= 0);
                if (this.zzKe && this.zzKf == 0) {
                    zzpk.m15v("No reference is left (including root). Cleaning up engine.");
                    zza(new C08923(this), new com.google.android.gms.internal.zzqp.zzb());
                } else {
                    zzpk.m15v("There are still references to the engine. Not destroying.");
                }
            }
        }
    }

    public static class zze extends zzqq<zzjj> {
        private zzc zzKk;

        public zze(zzc com_google_android_gms_internal_zzji_zzc) {
            this.zzKk = com_google_android_gms_internal_zzji_zzc;
        }

        public void finalize() {
            this.zzKk.release();
            this.zzKk = null;
        }

        public int getStatus() {
            return this.zzKk.getStatus();
        }

        public void reject() {
            this.zzKk.reject();
        }

        public void zza(com.google.android.gms.internal.zzqp.zzc<zzjj> com_google_android_gms_internal_zzqp_zzc_com_google_android_gms_internal_zzjj, com.google.android.gms.internal.zzqp.zza com_google_android_gms_internal_zzqp_zza) {
            this.zzKk.zza(com_google_android_gms_internal_zzqp_zzc_com_google_android_gms_internal_zzjj, com_google_android_gms_internal_zzqp_zza);
        }

        public /* synthetic */ void zzg(Object obj) {
            zzj((zzjj) obj);
        }

        public void zzj(zzjj com_google_android_gms_internal_zzjj) {
            this.zzKk.zzg(com_google_android_gms_internal_zzjj);
        }
    }

    public zzji(Context context, zzqh com_google_android_gms_internal_zzqh, String str) {
        this.zzrJ = new Object();
        this.zzJO = 1;
        this.zzJK = str;
        this.mContext = context.getApplicationContext();
        this.zztt = com_google_android_gms_internal_zzqh;
        this.zzJL = new zzb();
        this.zzJM = new zzb();
    }

    public zzji(Context context, zzqh com_google_android_gms_internal_zzqh, String str, zzpt<zzjf> com_google_android_gms_internal_zzpt_com_google_android_gms_internal_zzjf, zzpt<zzjf> com_google_android_gms_internal_zzpt_com_google_android_gms_internal_zzjf2) {
        this(context, com_google_android_gms_internal_zzqh, str);
        this.zzJL = com_google_android_gms_internal_zzpt_com_google_android_gms_internal_zzjf;
        this.zzJM = com_google_android_gms_internal_zzpt_com_google_android_gms_internal_zzjf2;
    }

    private zzd zza(@Nullable final zzaw com_google_android_gms_internal_zzaw) {
        final zzd com_google_android_gms_internal_zzji_zzd = new zzd(this.zzJM);
        zzw.zzcM().runOnUiThread(new Runnable(this) {
            final /* synthetic */ zzji zzJR;

            public void run() {
                final zzjf zza = this.zzJR.zza(this.zzJR.mContext, this.zzJR.zztt, com_google_android_gms_internal_zzaw);
                zza.zza(new com.google.android.gms.internal.zzjf.zza(this) {
                    final /* synthetic */ C04631 zzJT;

                    class C04601 implements Runnable {
                        final /* synthetic */ C08821 zzJU;

                        class C04591 implements Runnable {
                            final /* synthetic */ C04601 zzJV;

                            C04591(C04601 c04601) {
                                this.zzJV = c04601;
                            }

                            public void run() {
                                zza.destroy();
                            }
                        }

                        C04601(C08821 c08821) {
                            this.zzJU = c08821;
                        }

                        /* JADX WARNING: inconsistent code. */
                        /* Code decompiled incorrectly, please refer to instructions dump. */
                        public void run() {
                            /*
                            r3 = this;
                            r0 = r3.zzJU;
                            r0 = r0.zzJT;
                            r0 = r0.zzJR;
                            r1 = r0.zzrJ;
                            monitor-enter(r1);
                            r0 = r3.zzJU;	 Catch:{ all -> 0x0043 }
                            r0 = r0.zzJT;	 Catch:{ all -> 0x0043 }
                            r0 = r0;	 Catch:{ all -> 0x0043 }
                            r0 = r0.getStatus();	 Catch:{ all -> 0x0043 }
                            r2 = -1;
                            if (r0 == r2) goto L_0x0025;
                        L_0x0018:
                            r0 = r3.zzJU;	 Catch:{ all -> 0x0043 }
                            r0 = r0.zzJT;	 Catch:{ all -> 0x0043 }
                            r0 = r0;	 Catch:{ all -> 0x0043 }
                            r0 = r0.getStatus();	 Catch:{ all -> 0x0043 }
                            r2 = 1;
                            if (r0 != r2) goto L_0x0027;
                        L_0x0025:
                            monitor-exit(r1);	 Catch:{ all -> 0x0043 }
                        L_0x0026:
                            return;
                        L_0x0027:
                            r0 = r3.zzJU;	 Catch:{ all -> 0x0043 }
                            r0 = r0.zzJT;	 Catch:{ all -> 0x0043 }
                            r0 = r0;	 Catch:{ all -> 0x0043 }
                            r0.reject();	 Catch:{ all -> 0x0043 }
                            r0 = com.google.android.gms.ads.internal.zzw.zzcM();	 Catch:{ all -> 0x0043 }
                            r2 = new com.google.android.gms.internal.zzji$1$1$1$1;	 Catch:{ all -> 0x0043 }
                            r2.<init>(r3);	 Catch:{ all -> 0x0043 }
                            r0.runOnUiThread(r2);	 Catch:{ all -> 0x0043 }
                            r0 = "Could not receive loaded message in a timely manner. Rejecting.";
                            com.google.android.gms.internal.zzpk.m15v(r0);	 Catch:{ all -> 0x0043 }
                            monitor-exit(r1);	 Catch:{ all -> 0x0043 }
                            goto L_0x0026;
                        L_0x0043:
                            r0 = move-exception;
                            monitor-exit(r1);	 Catch:{ all -> 0x0043 }
                            throw r0;
                            */
                            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzji.1.1.1.run():void");
                        }
                    }

                    public void zzgN() {
                        zzpo.zzXC.postDelayed(new C04601(this), (long) zza.zzKa);
                    }
                });
                zza.zza("/jsLoaded", new zzid(this) {
                    final /* synthetic */ C04631 zzJT;

                    /* JADX WARNING: inconsistent code. */
                    /* Code decompiled incorrectly, please refer to instructions dump. */
                    public void zza(com.google.android.gms.internal.zzqw r4, java.util.Map<java.lang.String, java.lang.String> r5) {
                        /*
                        r3 = this;
                        r0 = r3.zzJT;
                        r0 = r0.zzJR;
                        r1 = r0.zzrJ;
                        monitor-enter(r1);
                        r0 = r3.zzJT;	 Catch:{ all -> 0x0051 }
                        r0 = r0;	 Catch:{ all -> 0x0051 }
                        r0 = r0.getStatus();	 Catch:{ all -> 0x0051 }
                        r2 = -1;
                        if (r0 == r2) goto L_0x001f;
                    L_0x0014:
                        r0 = r3.zzJT;	 Catch:{ all -> 0x0051 }
                        r0 = r0;	 Catch:{ all -> 0x0051 }
                        r0 = r0.getStatus();	 Catch:{ all -> 0x0051 }
                        r2 = 1;
                        if (r0 != r2) goto L_0x0021;
                    L_0x001f:
                        monitor-exit(r1);	 Catch:{ all -> 0x0051 }
                    L_0x0020:
                        return;
                    L_0x0021:
                        r0 = r3.zzJT;	 Catch:{ all -> 0x0051 }
                        r0 = r0.zzJR;	 Catch:{ all -> 0x0051 }
                        r2 = 0;
                        r0.zzJO = r2;	 Catch:{ all -> 0x0051 }
                        r0 = r3.zzJT;	 Catch:{ all -> 0x0051 }
                        r0 = r0.zzJR;	 Catch:{ all -> 0x0051 }
                        r0 = r0.zzJL;	 Catch:{ all -> 0x0051 }
                        r2 = r0;	 Catch:{ all -> 0x0051 }
                        r0.zzd(r2);	 Catch:{ all -> 0x0051 }
                        r0 = r3.zzJT;	 Catch:{ all -> 0x0051 }
                        r0 = r0;	 Catch:{ all -> 0x0051 }
                        r2 = r0;	 Catch:{ all -> 0x0051 }
                        r0.zzg(r2);	 Catch:{ all -> 0x0051 }
                        r0 = r3.zzJT;	 Catch:{ all -> 0x0051 }
                        r0 = r0.zzJR;	 Catch:{ all -> 0x0051 }
                        r2 = r3.zzJT;	 Catch:{ all -> 0x0051 }
                        r2 = r0;	 Catch:{ all -> 0x0051 }
                        r0.zzJN = r2;	 Catch:{ all -> 0x0051 }
                        r0 = "Successfully loaded JS Engine.";
                        com.google.android.gms.internal.zzpk.m15v(r0);	 Catch:{ all -> 0x0051 }
                        monitor-exit(r1);	 Catch:{ all -> 0x0051 }
                        goto L_0x0020;
                    L_0x0051:
                        r0 = move-exception;
                        monitor-exit(r1);	 Catch:{ all -> 0x0051 }
                        throw r0;
                        */
                        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzji.1.2.zza(com.google.android.gms.internal.zzqw, java.util.Map):void");
                    }
                });
                final zzqa com_google_android_gms_internal_zzqa = new zzqa();
                zzid c08843 = new zzid(this) {
                    final /* synthetic */ C04631 zzJT;

                    public void zza(zzqw com_google_android_gms_internal_zzqw, Map<String, String> map) {
                        synchronized (this.zzJT.zzJR.zzrJ) {
                            zzqf.zzbg("JS Engine is requesting an update");
                            if (this.zzJT.zzJR.zzJO == 0) {
                                zzqf.zzbg("Starting reload.");
                                this.zzJT.zzJR.zzJO = 2;
                                this.zzJT.zzJR.zzb(com_google_android_gms_internal_zzaw);
                            }
                            zza.zzb("/requestReload", (zzid) com_google_android_gms_internal_zzqa.get());
                        }
                    }
                };
                com_google_android_gms_internal_zzqa.set(c08843);
                zza.zza("/requestReload", c08843);
                if (this.zzJR.zzJK.endsWith(".js")) {
                    zza.zzam(this.zzJR.zzJK);
                } else if (this.zzJR.zzJK.startsWith("<html>")) {
                    zza.zzao(this.zzJR.zzJK);
                } else {
                    zza.zzan(this.zzJR.zzJK);
                }
                zzpo.zzXC.postDelayed(new Runnable(this) {
                    final /* synthetic */ C04631 zzJT;

                    class C04611 implements Runnable {
                        final /* synthetic */ C04624 zzJX;

                        C04611(C04624 c04624) {
                            this.zzJX = c04624;
                        }

                        public void run() {
                            zza.destroy();
                        }
                    }

                    /* JADX WARNING: inconsistent code. */
                    /* Code decompiled incorrectly, please refer to instructions dump. */
                    public void run() {
                        /*
                        r3 = this;
                        r0 = r3.zzJT;
                        r0 = r0.zzJR;
                        r1 = r0.zzrJ;
                        monitor-enter(r1);
                        r0 = r3.zzJT;	 Catch:{ all -> 0x003b }
                        r0 = r0;	 Catch:{ all -> 0x003b }
                        r0 = r0.getStatus();	 Catch:{ all -> 0x003b }
                        r2 = -1;
                        if (r0 == r2) goto L_0x001f;
                    L_0x0014:
                        r0 = r3.zzJT;	 Catch:{ all -> 0x003b }
                        r0 = r0;	 Catch:{ all -> 0x003b }
                        r0 = r0.getStatus();	 Catch:{ all -> 0x003b }
                        r2 = 1;
                        if (r0 != r2) goto L_0x0021;
                    L_0x001f:
                        monitor-exit(r1);	 Catch:{ all -> 0x003b }
                    L_0x0020:
                        return;
                    L_0x0021:
                        r0 = r3.zzJT;	 Catch:{ all -> 0x003b }
                        r0 = r0;	 Catch:{ all -> 0x003b }
                        r0.reject();	 Catch:{ all -> 0x003b }
                        r0 = com.google.android.gms.ads.internal.zzw.zzcM();	 Catch:{ all -> 0x003b }
                        r2 = new com.google.android.gms.internal.zzji$1$4$1;	 Catch:{ all -> 0x003b }
                        r2.<init>(r3);	 Catch:{ all -> 0x003b }
                        r0.runOnUiThread(r2);	 Catch:{ all -> 0x003b }
                        r0 = "Could not receive loaded message in a timely manner. Rejecting.";
                        com.google.android.gms.internal.zzpk.m15v(r0);	 Catch:{ all -> 0x003b }
                        monitor-exit(r1);	 Catch:{ all -> 0x003b }
                        goto L_0x0020;
                    L_0x003b:
                        r0 = move-exception;
                        monitor-exit(r1);	 Catch:{ all -> 0x003b }
                        throw r0;
                        */
                        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzji.1.4.run():void");
                    }
                }, (long) zza.zzJZ);
            }
        });
        return com_google_android_gms_internal_zzji_zzd;
    }

    protected zzjf zza(Context context, zzqh com_google_android_gms_internal_zzqh, @Nullable zzaw com_google_android_gms_internal_zzaw) {
        return new zzjh(context, com_google_android_gms_internal_zzqh, com_google_android_gms_internal_zzaw, null);
    }

    protected zzd zzb(@Nullable zzaw com_google_android_gms_internal_zzaw) {
        final zzd zza = zza(com_google_android_gms_internal_zzaw);
        zza.zza(new com.google.android.gms.internal.zzqp.zzc<zzjf>(this) {
            final /* synthetic */ zzji zzJR;

            public void zza(zzjf com_google_android_gms_internal_zzjf) {
                synchronized (this.zzJR.zzrJ) {
                    this.zzJR.zzJO = 0;
                    if (!(this.zzJR.zzJN == null || zza == this.zzJR.zzJN)) {
                        zzpk.m15v("New JS engine is loaded, marking previous one as destroyable.");
                        this.zzJR.zzJN.zzgR();
                    }
                    this.zzJR.zzJN = zza;
                }
            }

            public /* synthetic */ void zzd(Object obj) {
                zza((zzjf) obj);
            }
        }, new com.google.android.gms.internal.zzqp.zza(this) {
            final /* synthetic */ zzji zzJR;

            public void run() {
                synchronized (this.zzJR.zzrJ) {
                    this.zzJR.zzJO = 1;
                    zzpk.m15v("Failed loading new engine. Marking new engine destroyable.");
                    zza.zzgR();
                }
            }
        });
        return zza;
    }

    public zzc zzc(@Nullable zzaw com_google_android_gms_internal_zzaw) {
        zzc zzgP;
        synchronized (this.zzrJ) {
            if (this.zzJN == null || this.zzJN.getStatus() == -1) {
                this.zzJO = 2;
                this.zzJN = zzb(com_google_android_gms_internal_zzaw);
                zzgP = this.zzJN.zzgP();
            } else if (this.zzJO == 0) {
                zzgP = this.zzJN.zzgP();
            } else if (this.zzJO == 1) {
                this.zzJO = 2;
                zzb(com_google_android_gms_internal_zzaw);
                zzgP = this.zzJN.zzgP();
            } else if (this.zzJO == 2) {
                zzgP = this.zzJN.zzgP();
            } else {
                zzgP = this.zzJN.zzgP();
            }
        }
        return zzgP;
    }

    public zzc zzgO() {
        return zzc(null);
    }
}
