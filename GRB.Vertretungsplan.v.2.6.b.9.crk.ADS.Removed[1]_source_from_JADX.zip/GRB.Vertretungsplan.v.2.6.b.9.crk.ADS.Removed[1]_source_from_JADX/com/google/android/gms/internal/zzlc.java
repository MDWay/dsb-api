package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;

public interface zzlc {
    zzqm<Bundle> zzt(Context context);
}
