package com.google.android.gms.internal;

import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;

public interface zzzl {
    PendingResult<Status> zza(zzzm com_google_android_gms_internal_zzzm);
}
