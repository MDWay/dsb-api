package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences;

@zzme
public class zzgb {
    public SharedPreferences zzn(Context context) {
        return context.getSharedPreferences("google_ads_flags", 1);
    }
}
