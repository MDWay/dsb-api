package com.google.android.gms;

import com.bossani.vertretungsplan.C0249R;

public final class C0284R {

    public static final class attr {
        public static final int adSize = 2130772002;
        public static final int adSizes = 2130772003;
        public static final int adUnitId = 2130772004;
        public static final int buttonSize = 2130772240;
        public static final int circleCrop = 2130772204;
        public static final int colorScheme = 2130772241;
        public static final int imageAspectRatio = 2130772203;
        public static final int imageAspectRatioAdjust = 2130772202;
        public static final int scopeUris = 2130772242;
    }

    public static final class color {
        public static final int common_google_signin_btn_text_dark = 2131624224;
        public static final int common_google_signin_btn_text_dark_default = 2131624126;
        public static final int common_google_signin_btn_text_dark_disabled = 2131624127;
        public static final int common_google_signin_btn_text_dark_focused = 2131624128;
        public static final int common_google_signin_btn_text_dark_pressed = 2131624129;
        public static final int common_google_signin_btn_text_light = 2131624225;
        public static final int common_google_signin_btn_text_light_default = 2131624130;
        public static final int common_google_signin_btn_text_light_disabled = 2131624131;
        public static final int common_google_signin_btn_text_light_focused = 2131624132;
        public static final int common_google_signin_btn_text_light_pressed = 2131624133;
        public static final int common_google_signin_btn_tint = 2131624226;
    }

    public static final class drawable {
        public static final int common_full_open_on_phone = 2130837589;
        public static final int common_google_signin_btn_icon_dark = 2130837590;
        public static final int common_google_signin_btn_icon_dark_focused = 2130837591;
        public static final int common_google_signin_btn_icon_dark_normal = 2130837592;
        public static final int common_google_signin_btn_icon_dark_normal_background = 2130837593;
        public static final int common_google_signin_btn_icon_disabled = 2130837594;
        public static final int common_google_signin_btn_icon_light = 2130837595;
        public static final int common_google_signin_btn_icon_light_focused = 2130837596;
        public static final int common_google_signin_btn_icon_light_normal = 2130837597;
        public static final int common_google_signin_btn_icon_light_normal_background = 2130837598;
        public static final int common_google_signin_btn_text_dark = 2130837599;
        public static final int common_google_signin_btn_text_dark_focused = 2130837600;
        public static final int common_google_signin_btn_text_dark_normal = 2130837601;
        public static final int common_google_signin_btn_text_dark_normal_background = 2130837602;
        public static final int common_google_signin_btn_text_disabled = 2130837603;
        public static final int common_google_signin_btn_text_light = 2130837604;
        public static final int common_google_signin_btn_text_light_focused = 2130837605;
        public static final int common_google_signin_btn_text_light_normal = 2130837606;
        public static final int common_google_signin_btn_text_light_normal_background = 2130837607;
        public static final int googleg_disabled_color_18 = 2130837619;
        public static final int googleg_standard_color_18 = 2130837620;
    }

    public static final class id {
        public static final int adjust_height = 2131755069;
        public static final int adjust_width = 2131755070;
        public static final int auto = 2131755047;
        public static final int center = 2131755049;
        public static final int dark = 2131755079;
        public static final int icon_only = 2131755076;
        public static final int light = 2131755080;
        public static final int none = 2131755030;
        public static final int normal = 2131755026;
        public static final int radio = 2131755111;
        public static final int standard = 2131755077;
        public static final int text = 2131755206;
        public static final int text1 = 2131755181;
        public static final int text2 = 2131755182;
        public static final int toolbar = 2131755138;
        public static final int wide = 2131755078;
        public static final int wrap_content = 2131755046;
    }

    public static final class integer {
        public static final int google_play_services_version = 2131558406;
    }

    public static final class string {
        public static final int accept = 2131296275;
        public static final int common_google_play_services_enable_button = 2131296276;
        public static final int common_google_play_services_enable_text = 2131296277;
        public static final int common_google_play_services_enable_title = 2131296278;
        public static final int common_google_play_services_install_button = 2131296279;
        public static final int common_google_play_services_install_text = 2131296280;
        public static final int common_google_play_services_install_title = 2131296281;
        public static final int common_google_play_services_notification_ticker = 2131296282;
        public static final int common_google_play_services_unknown_issue = 2131296283;
        public static final int common_google_play_services_unsupported_text = 2131296284;
        public static final int common_google_play_services_update_button = 2131296285;
        public static final int common_google_play_services_update_text = 2131296286;
        public static final int common_google_play_services_update_title = 2131296287;
        public static final int common_google_play_services_updating_text = 2131296288;
        public static final int common_google_play_services_wear_update_text = 2131296289;
        public static final int common_open_on_phone = 2131296290;
        public static final int common_signin_button_text = 2131296291;
        public static final int common_signin_button_text_long = 2131296292;
        public static final int create_calendar_message = 2131296293;
        public static final int create_calendar_title = 2131296294;
        public static final int debug_menu_ad_information = 2131296295;
        public static final int debug_menu_creative_preview = 2131296296;
        public static final int debug_menu_title = 2131296297;
        public static final int debug_menu_troubleshooting = 2131296298;
        public static final int decline = 2131296299;
        public static final int store_picture_message = 2131296302;
        public static final int store_picture_title = 2131296303;
    }

    public static final class style {
        public static final int Theme_IAPTheme = 2131427622;
    }

    public static final class styleable {
        public static final int[] AdsAttrs = new int[]{C0249R.attr.adSize, C0249R.attr.adSizes, C0249R.attr.adUnitId};
        public static final int AdsAttrs_adSize = 0;
        public static final int AdsAttrs_adSizes = 1;
        public static final int AdsAttrs_adUnitId = 2;
        public static final int[] LoadingImageView = new int[]{C0249R.attr.imageAspectRatioAdjust, C0249R.attr.imageAspectRatio, C0249R.attr.circleCrop};
        public static final int LoadingImageView_circleCrop = 2;
        public static final int LoadingImageView_imageAspectRatio = 1;
        public static final int LoadingImageView_imageAspectRatioAdjust = 0;
        public static final int[] SignInButton = new int[]{C0249R.attr.buttonSize, C0249R.attr.colorScheme, C0249R.attr.scopeUris};
        public static final int SignInButton_buttonSize = 0;
        public static final int SignInButton_colorScheme = 1;
        public static final int SignInButton_scopeUris = 2;
    }
}
